import { pgTable, text, serial, integer, boolean, timestamp, varchar, numeric, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User roles
export const UserRole = {
  ADMIN: "admin",
  FARMER: "farmer",
  BUYER: "buyer",
  DISTRIBUTOR: "distributor",
} as const;

// User Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default(UserRole.FARMER),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

// Product Categories
export const ProductCategory = {
  VEGETABLES: "vegetables",
  FRUITS: "fruits",
  GRAINS: "grains",
  DAIRY: "dairy",
  LIVESTOCK: "livestock",
  OTHER: "other",
} as const;

// Product Stock Status
export const StockStatus = {
  IN_STOCK: "in_stock",
  LOW_STOCK: "low_stock",
  OUT_OF_STOCK: "out_of_stock",
} as const;

// Products Schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull().default(ProductCategory.OTHER),
  stockQuantity: numeric("stock_quantity").notNull().default("0"),
  unit: text("unit").notNull().default("kg"),
  pricePerUnit: numeric("price_per_unit").notNull().default("0"),
  status: text("status").notNull().default(StockStatus.OUT_OF_STOCK),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  userId: true,
  status: true,
  createdAt: true,
  updatedAt: true,
});

// Order Status
export const OrderStatus = {
  PENDING: "pending",
  PROCESSING: "processing",
  COMPLETED: "completed",
  CANCELED: "canceled",
} as const;

// Payment Status
export const PaymentStatus = {
  AWAITING: "awaiting",
  PAID: "paid",
  REFUNDED: "refunded",
} as const;

// Orders Schema
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 10 }).notNull().unique(),
  customerId: integer("customer_id").notNull(),
  userId: integer("user_id").notNull(),
  orderDate: timestamp("order_date").notNull().defaultNow(),
  totalAmount: numeric("total_amount").notNull().default("0"),
  status: text("status").notNull().default(OrderStatus.PENDING),
  paymentStatus: text("payment_status").notNull().default(PaymentStatus.AWAITING),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  orderNumber: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
});

// Order Items Schema
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  quantity: numeric("quantity").notNull(),
  unitPrice: numeric("unit_price").notNull(),
  subtotal: numeric("subtotal").notNull(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

// Market Prices Schema
export const marketPrices = pgTable("market_prices", {
  id: serial("id").primaryKey(),
  productName: text("product_name").notNull(),
  category: text("category").notNull(),
  price: numeric("price").notNull(),
  unit: text("unit").notNull().default("kg"),
  market: text("market").notNull(),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMarketPriceSchema = createInsertSchema(marketPrices).omit({
  id: true,
  createdAt: true,
});

// Financial Transaction Types
export const TransactionType = {
  INCOME: "income",
  EXPENSE: "expense",
} as const;

// Financial Transactions Schema
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  amount: numeric("amount").notNull(),
  description: text("description").notNull(),
  category: text("category"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  userId: true,
  createdAt: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

export type InsertMarketPrice = z.infer<typeof insertMarketPriceSchema>;
export type MarketPrice = typeof marketPrices.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
