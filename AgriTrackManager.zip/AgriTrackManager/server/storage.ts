import { 
  User, InsertUser, 
  Product, InsertProduct, 
  Order, InsertOrder, 
  OrderItem, InsertOrderItem, 
  MarketPrice, InsertMarketPrice,
  Transaction, InsertTransaction,
  UserRole, StockStatus, OrderStatus, PaymentStatus, TransactionType,
  users, products, orders, orderItems, marketPrices, transactions
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db } from "./db";
import { pool } from "./db";
import { eq, and, desc } from "drizzle-orm";

// Initialize PostgreSQL session store
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User related methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>; // New method to get all users for admin page
  
  // Product related methods
  getProducts(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(userId: number, product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: InsertProduct): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  
  // Order related methods
  getOrders(userId: number): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(userId: number, order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: InsertOrder): Promise<Order>;
  
  // Order items related methods
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  
  // Market prices related methods
  getMarketPrices(): Promise<MarketPrice[]>;
  
  // Financial transactions related methods
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(userId: number, transaction: InsertTransaction): Promise<Transaction>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
    
    // Initialize market prices
    this.initializeMarketPrices();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Product methods
  async getProducts(userId: number): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.userId, userId));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.id, id));
    return product;
  }

  async createProduct(userId: number, insertProduct: InsertProduct): Promise<Product> {
    // Determine stock status based on quantity
    let status = StockStatus.OUT_OF_STOCK;
    const quantity = Number(insertProduct.stockQuantity);
    
    if (quantity > 50) {
      status = StockStatus.IN_STOCK;
    } else if (quantity > 0) {
      status = StockStatus.LOW_STOCK;
    }
    
    const [product] = await db
      .insert(products)
      .values({
        ...insertProduct,
        userId,
        status
      })
      .returning();
    
    return product;
  }

  async updateProduct(id: number, insertProduct: InsertProduct): Promise<Product> {
    // Determine stock status based on quantity
    let status = StockStatus.OUT_OF_STOCK;
    const quantity = Number(insertProduct.stockQuantity);
    
    if (quantity > 50) {
      status = StockStatus.IN_STOCK;
    } else if (quantity > 0) {
      status = StockStatus.LOW_STOCK;
    }
    
    const [product] = await db
      .update(products)
      .set({
        ...insertProduct,
        status,
        updatedAt: new Date()
      })
      .where(eq(products.id, id))
      .returning();
    
    return product;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  // Order methods
  async getOrders(userId: number): Promise<Order[]> {
    return await db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  }

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, id));
    return order;
  }

  async createOrder(userId: number, insertOrder: InsertOrder): Promise<Order> {
    // Generate order number (you may want to improve this in production)
    const allOrders = await db.select().from(orders);
    const orderNumber = `OR-${1000 + allOrders.length}`;
    
    const [order] = await db
      .insert(orders)
      .values({
        ...insertOrder,
        userId,
        orderNumber
      })
      .returning();
    
    return order;
  }

  async updateOrder(id: number, insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set({
        ...insertOrder,
        updatedAt: new Date()
      })
      .where(eq(orders.id, id))
      .returning();
    
    return order;
  }

  // Order items methods
  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));
  }

  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const [orderItem] = await db
      .insert(orderItems)
      .values(insertOrderItem)
      .returning();
    
    return orderItem;
  }

  // Market prices methods
  async getMarketPrices(): Promise<MarketPrice[]> {
    return await db.select().from(marketPrices);
  }

  // Initialize sample market prices
  private async initializeMarketPrices() {
    // Check if we already have market prices
    const existingPrices = await db.select().from(marketPrices);
    
    if (existingPrices.length > 0) {
      return; // Already initialized
    }
    
    const today = new Date();
    
    const samplePrices = [
      { productName: "Tomatoes", category: "vegetables", price: "2.50", unit: "kg", market: "Central Market" },
      { productName: "Potatoes", category: "vegetables", price: "1.75", unit: "kg", market: "Central Market" },
      { productName: "Apples", category: "fruits", price: "3.25", unit: "kg", market: "East Region Market" },
      { productName: "Carrots", category: "vegetables", price: "1.50", unit: "kg", market: "South Market" },
      { productName: "Rice", category: "grains", price: "4.50", unit: "kg", market: "North Market" },
      { productName: "Corn", category: "vegetables", price: "1.25", unit: "kg", market: "West Market" },
      { productName: "Lettuce", category: "vegetables", price: "2.00", unit: "kg", market: "Farmers Market" },
      { productName: "Bananas", category: "fruits", price: "1.80", unit: "kg", market: "Central Market" },
      { productName: "Wheat", category: "grains", price: "2.75", unit: "kg", market: "East Region Market" },
      { productName: "Oranges", category: "fruits", price: "2.20", unit: "kg", market: "South Market" }
    ];
    
    for (const price of samplePrices) {
      await db.insert(marketPrices).values({
        ...price,
        date: today,
        createdAt: today
      });
    }
  }

  // Financial transactions methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(userId: number, insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values({
        ...insertTransaction,
        userId
      })
      .returning();
    
    return transaction;
  }
}

export const storage = new DatabaseStorage();