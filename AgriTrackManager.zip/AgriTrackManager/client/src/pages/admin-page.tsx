import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { User, UserRole } from "@shared/schema";
import { format } from "date-fns";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  UserCog, 
  Users, 
  Shield, 
  AlertTriangle, 
  RefreshCw, 
  LogOut, 
  Search, 
  Lock, 
  UserPlus,
  CheckCircle2,
  XCircle,
  User as UserIcon,
  Calendar,
  Filter
} from "lucide-react";

export default function AdminPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState("users");
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();

  // Check if user is admin, if not, prompt for admin password
  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }

    if (user.role !== UserRole.ADMIN) {
      setShowPasswordDialog(true);
    } else {
      setIsAdminAuthenticated(true);
    }
  }, [user, navigate]);

  // Handle admin password validation
  const handleAdminAuth = () => {
    // In a real application, you would verify this against the server
    if (passwordInput === "admin123") {
      setIsAdminAuthenticated(true);
      setShowPasswordDialog(false);
      toast({
        title: "Admin Access Granted",
        description: "Welcome to the admin dashboard",
      });
    } else {
      toast({
        title: "Access Denied",
        description: "Incorrect admin password",
        variant: "destructive",
      });
    }
  };

  // If not authenticated and not showing dialog, redirect
  useEffect(() => {
    if (!isAdminAuthenticated && !showPasswordDialog && user) {
      navigate("/");
    }
  }, [isAdminAuthenticated, showPasswordDialog, navigate, user]);

  // Fetch users data
  const { data: users, isLoading: isLoadingUsers, refetch: refetchUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: isAdminAuthenticated,
  });

  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Filter users based on search term and role filter
  const filteredUsers = users
    ? users.filter(user => 
        (user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
         user.username.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (roleFilter === "all" || user.role === roleFilter)
      )
    : [];

  // If not authenticated, render auth dialog
  if (!isAdminAuthenticated) {
    return (
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Admin Authentication Required</DialogTitle>
            <DialogDescription>
              Enter the admin password to access the admin dashboard
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0 bg-yellow-100 p-2 rounded-full">
                <Shield className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium leading-none">Restricted Area</p>
                <p className="text-sm text-neutral-500">
                  This page is only accessible to administrators
                </p>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="admin-password">Admin Password</Label>
              <Input
                id="admin-password"
                type="password"
                placeholder="Enter admin password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button variant="outline" onClick={() => navigate("/")}>
              Go Back
            </Button>
            <Button type="submit" onClick={handleAdminAuth}>
              <Lock className="mr-2 h-4 w-4" /> Authenticate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  // Render admin dashboard
  return (
    <div className="min-h-screen bg-neutral-50">
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-primary/10 p-2 rounded-lg mr-3">
              <UserCog className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary">AgriTrack Admin</h1>
              <p className="text-sm text-neutral-500">System Management Dashboard</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={() => navigate("/")}>
              Back to App
            </Button>
            <Button variant="destructive" size="sm" onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" /> Logout
            </Button>
          </div>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Dashboard</CardTitle>
                <CardDescription>System administration</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <nav className="flex flex-col py-2">
                  <Button 
                    variant={activeTab === "users" ? "secondary" : "ghost"} 
                    className="justify-start mb-1 font-normal" 
                    onClick={() => setActiveTab("users")}
                  >
                    <Users className="mr-2 h-5 w-5" /> User Management
                  </Button>
                  <Button 
                    variant={activeTab === "activity" ? "secondary" : "ghost"} 
                    className="justify-start mb-1 font-normal"
                    onClick={() => setActiveTab("activity")}
                  >
                    <Calendar className="mr-2 h-5 w-5" /> Recent Activity
                  </Button>
                  <Button 
                    variant={activeTab === "security" ? "secondary" : "ghost"} 
                    className="justify-start font-normal"
                    onClick={() => setActiveTab("security")}
                  >
                    <Shield className="mr-2 h-5 w-5" /> Security Settings
                  </Button>
                </nav>
              </CardContent>
              <CardFooter className="border-t pt-4 mt-4">
                <div className="w-full">
                  <p className="text-xs text-neutral-500 mb-2">Logged in as:</p>
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white mr-2">
                      {user?.fullName?.charAt(0) || "A"}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{user?.fullName}</p>
                      <p className="text-xs text-neutral-500">
                        <Badge variant="secondary" className="text-primary">
                          Administrator
                        </Badge>
                      </p>
                    </div>
                  </div>
                </div>
              </CardFooter>
            </Card>
            
            <Card className="mt-4">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">System Status</CardTitle>
                <CardDescription>System health overview</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Server Status</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" /> Online
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Database</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" /> Connected
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">API Health</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" /> Normal
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Last Update</span>
                  <span className="text-xs text-neutral-500">
                    {new Date().toLocaleString()}
                  </span>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" size="sm" onClick={() => {
                  refetchUsers();
                  toast({
                    title: "System refreshed",
                    description: "Data has been updated from the server",
                  });
                }}>
                  <RefreshCw className="h-3 w-3 mr-2" /> Refresh Dashboard
                </Button>
              </CardFooter>
            </Card>
          </div>
          
          {/* Main Content */}
          <div className="md:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="users">User Management</TabsTrigger>
                <TabsTrigger value="activity">Activity Log</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
              </TabsList>
              
              {/* Users Tab */}
              <TabsContent value="users">
                <Card>
                  <CardHeader>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>
                      View and manage all users registered in the system
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col md:flex-row gap-3 mb-4">
                      <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral-400" />
                        <Input
                          placeholder="Search by name or username..."
                          className="pl-8"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <Filter className="h-4 w-4 text-neutral-400" />
                        <select
                          className="bg-neutral-50 text-sm border rounded-md px-2 py-1.5"
                          value={roleFilter}
                          onChange={(e) => setRoleFilter(e.target.value)}
                        >
                          <option value="all">All Roles</option>
                          <option value={UserRole.ADMIN}>Admin</option>
                          <option value={UserRole.FARMER}>Farmer</option>
                          <option value={UserRole.BUYER}>Buyer</option>
                          <option value={UserRole.DISTRIBUTOR}>Distributor</option>
                        </select>
                      </div>
                      <Button variant="outline" onClick={() => refetchUsers()}>
                        <RefreshCw className="h-4 w-4 mr-2" /> Refresh
                      </Button>
                    </div>
                    
                    {isLoadingUsers ? (
                      <div className="flex justify-center items-center py-8">
                        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
                      </div>
                    ) : (
                      <ScrollArea className="h-[500px]">
                        <Table>
                          <TableHeader className="sticky top-0 bg-white">
                            <TableRow>
                              <TableHead>User ID</TableHead>
                              <TableHead>Full Name</TableHead>
                              <TableHead>Username</TableHead>
                              <TableHead>Role</TableHead>
                              <TableHead>Joined</TableHead>
                              <TableHead>Status</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredUsers.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                                  {searchTerm || roleFilter !== "all" ? (
                                    <>No users found matching your search criteria.</>
                                  ) : (
                                    <>No users found in the system.</>
                                  )}
                                </TableCell>
                              </TableRow>
                            ) : (
                              filteredUsers.map((user) => (
                                <TableRow key={user.id}>
                                  <TableCell className="font-mono">{user.id}</TableCell>
                                  <TableCell className="font-medium">
                                    <div className="flex items-center">
                                      <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center text-primary mr-2">
                                        {user.fullName.charAt(0)}
                                      </div>
                                      {user.fullName}
                                    </div>
                                  </TableCell>
                                  <TableCell>{user.username}</TableCell>
                                  <TableCell>
                                    <Badge 
                                      variant={user.role === UserRole.ADMIN ? "default" : "outline"}
                                      className={
                                        user.role === UserRole.ADMIN 
                                          ? "bg-purple-100 text-purple-800 hover:bg-purple-200" 
                                          : user.role === UserRole.FARMER
                                          ? "bg-green-50 text-green-700 border-green-200"
                                          : user.role === UserRole.BUYER
                                          ? "bg-blue-50 text-blue-700 border-blue-200"
                                          : "bg-amber-50 text-amber-700 border-amber-200"
                                      }
                                    >
                                      {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>
                                    {user.createdAt ? (
                                      format(new Date(user.createdAt), 'MMM dd, yyyy')
                                    ) : "N/A"}
                                  </TableCell>
                                  <TableCell>
                                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                                      Active
                                    </Badge>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    )}
                  </CardContent>
                  <CardFooter className="border-t flex justify-between">
                    <div className="text-sm text-neutral-500">
                      {filteredUsers.length} users shown
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <UserPlus className="h-4 w-4 mr-2" /> Add User
                      </Button>
                      <Button variant="outline" size="sm">
                        Export
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>User Statistics</CardTitle>
                    <CardDescription>
                      Overview of registration and activity
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <UserPlus className="h-5 w-5 text-primary" />
                          <h3 className="text-sm font-medium">Total Users</h3>
                        </div>
                        <p className="text-2xl font-bold">{users?.length || 0}</p>
                        <p className="text-xs text-neutral-500 mt-1">All registered accounts</p>
                      </div>
                      
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <UserIcon className="h-5 w-5 text-green-600" />
                          <h3 className="text-sm font-medium">Farmers</h3>
                        </div>
                        <p className="text-2xl font-bold">
                          {users?.filter(u => u.role === UserRole.FARMER).length || 0}
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">Farmer accounts</p>
                      </div>
                      
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <UserIcon className="h-5 w-5 text-blue-600" />
                          <h3 className="text-sm font-medium">Buyers</h3>
                        </div>
                        <p className="text-2xl font-bold">
                          {users?.filter(u => u.role === UserRole.BUYER).length || 0}
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">Buyer accounts</p>
                      </div>
                      
                      <div className="bg-white rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <UserIcon className="h-5 w-5 text-amber-600" />
                          <h3 className="text-sm font-medium">Distributors</h3>
                        </div>
                        <p className="text-2xl font-bold">
                          {users?.filter(u => u.role === UserRole.DISTRIBUTOR).length || 0}
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">Distributor accounts</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Activity Tab */}
              <TabsContent value="activity">
                <Card>
                  <CardHeader>
                    <CardTitle>Activity Log</CardTitle>
                    <CardDescription>
                      Recent system activities and user events
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert className="mb-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Activity Logging</AlertTitle>
                      <AlertDescription>
                        Detailed activity logging will be implemented in a future update.
                      </AlertDescription>
                    </Alert>
                    
                    <div className="space-y-4">
                      {/* Sample activity log items */}
                      <div className="bg-white border rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-blue-100 p-2 rounded-full">
                            <UserPlus className="h-5 w-5 text-blue-700" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">New User Registration</p>
                            <p className="text-sm text-neutral-600">User "John Farmer" created a new account</p>
                            <p className="text-xs text-neutral-500 mt-1">Today, {new Date().toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white border rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-green-100 p-2 rounded-full">
                            <Shield className="h-5 w-5 text-green-700" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">Admin Login</p>
                            <p className="text-sm text-neutral-600">Administrator successfully logged in</p>
                            <p className="text-xs text-neutral-500 mt-1">Today, {new Date().toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-white border rounded-lg p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-amber-100 p-2 rounded-full">
                            <Users className="h-5 w-5 text-amber-700" />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">System Init</p>
                            <p className="text-sm text-neutral-600">System initialized with default user accounts</p>
                            <p className="text-xs text-neutral-500 mt-1">Today, {new Date().toLocaleTimeString()}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Security Tab */}
              <TabsContent value="security">
                <Card>
                  <CardHeader>
                    <CardTitle>Security Settings</CardTitle>
                    <CardDescription>
                      Manage system security and access controls
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert className="mb-4">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertTitle>Admin Notice</AlertTitle>
                      <AlertDescription>
                        Additional security features will be implemented in future updates.
                      </AlertDescription>
                    </Alert>
                    
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-base font-medium mb-2">Admin Password</h3>
                        <p className="text-sm text-neutral-600 mb-4">
                          Change the admin password used to access this dashboard
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="current-password">Current Password</Label>
                            <Input type="password" id="current-password" placeholder="Enter current password" />
                          </div>
                          <div>
                            <Label htmlFor="new-password">New Password</Label>
                            <Input type="password" id="new-password" placeholder="Enter new password" />
                          </div>
                        </div>
                        <Button size="sm" className="mt-4">Update Password</Button>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h3 className="text-base font-medium mb-2">Access Control</h3>
                        <p className="text-sm text-neutral-600 mb-4">
                          Manage user roles and permissions
                        </p>
                        
                        <div className="space-y-2">
                          <div className="flex items-center justify-between py-2 border-b">
                            <div>
                              <p className="font-medium">Farmers</p>
                              <p className="text-sm text-neutral-500">Can manage their farm inventory and sales</p>
                            </div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">Enabled</Badge>
                          </div>
                          
                          <div className="flex items-center justify-between py-2 border-b">
                            <div>
                              <p className="font-medium">Buyers</p>
                              <p className="text-sm text-neutral-500">Can browse products and place orders</p>
                            </div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">Enabled</Badge>
                          </div>
                          
                          <div className="flex items-center justify-between py-2 border-b">
                            <div>
                              <p className="font-medium">Distributors</p>
                              <p className="text-sm text-neutral-500">Can manage distribution networks</p>
                            </div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">Enabled</Badge>
                          </div>
                          
                          <div className="flex items-center justify-between py-2">
                            <div>
                              <p className="font-medium">Administrators</p>
                              <p className="text-sm text-neutral-500">Full system access and management</p>
                            </div>
                            <Badge variant="outline" className="bg-green-50 text-green-700">Enabled</Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  );
}