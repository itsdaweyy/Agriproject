import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Product, Transaction } from "@shared/schema";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import StatsCard from "@/components/dashboard/stats-card";
import ChartContainer from "@/components/dashboard/chart-container";
import ActivityItem from "@/components/dashboard/activity-item";

// Icons
import { 
  CircleDollarSign, 
  ShoppingCart, 
  Package,
  AlertTriangle,
  Loader2
} from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });
  
  const { data: orders, isLoading: isLoadingOrders } = useQuery({
    queryKey: ["/api/orders"],
  });
  
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  const isLoading = isLoadingProducts || isLoadingOrders || isLoadingTransactions;

  // Calculate dashboard stats
  const calculateStats = () => {
    if (isLoading) return {
      totalProducts: 0,
      pendingOrders: 0,
      totalRevenue: 0,
      marketAlerts: 3 // Static for demo
    };
    
    const totalProducts = products?.length || 0;
    const pendingOrders = orders?.filter(order => order.status === "pending").length || 0;
    
    // Calculate total revenue from income transactions
    const totalRevenue = transactions
      ?.filter(tx => tx.type === "income")
      .reduce((sum, tx) => sum + Number(tx.amount), 0) || 0;
    
    return {
      totalProducts,
      pendingOrders,
      totalRevenue,
      marketAlerts: 3 // Static for demo
    };
  };
  
  const stats = calculateStats();

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-neutral-800 font-heading">Dashboard</h2>
              <p className="text-neutral-600">Welcome, {user?.fullName || "User"}!</p>
            </div>

            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {/* Stats Row */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <StatsCard 
                    title="Total Products"
                    value={stats.totalProducts}
                    icon={<Package />}
                    trend={{
                      value: 3.5,
                      isUp: true,
                      label: "from last month"
                    }}
                    color="primary"
                  />
                  
                  <StatsCard 
                    title="Pending Orders"
                    value={stats.pendingOrders}
                    icon={<ShoppingCart />}
                    trend={{
                      value: 5.2,
                      isUp: true,
                      label: "from last week"
                    }}
                    color="secondary"
                  />
                  
                  <StatsCard 
                    title="Total Revenue"
                    value={`$${stats.totalRevenue.toFixed(2)}`}
                    icon={<CircleDollarSign />}
                    trend={{
                      value: 2.3,
                      isUp: false,
                      label: "from last month"
                    }}
                    color="earth"
                  />
                  
                  <StatsCard 
                    title="Market Alerts"
                    value={stats.marketAlerts}
                    icon={<AlertTriangle />}
                    label="New price changes"
                    color="green"
                  />
                </div>

                {/* Charts Row */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
                  <ChartContainer 
                    title="Monthly Sales Revenue"
                    type="bar"
                  />
                  
                  <ChartContainer 
                    title="Product Distribution"
                    type="pie"
                  />
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-lg shadow-md p-4 mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium text-neutral-800">Recent Activity</h3>
                    <a href="#" className="text-sm text-primary hover:underline">View all</a>
                  </div>
                  
                  <div className="space-y-3">
                    <ActivityItem 
                      icon="money"
                      title="New order #OR-789 received"
                      subtitle="From: Sophia's Organic Market"
                      time="30 minutes ago"
                    />
                    
                    <ActivityItem 
                      icon="inventory"
                      title="Inventory updated"
                      subtitle="30 kg of Tomatoes added to stock"
                      time="2 hours ago"
                    />
                    
                    <ActivityItem 
                      icon="order"
                      title="Order #OR-654 completed"
                      subtitle="Payment received: $345.00"
                      time="Yesterday at 4:30 PM"
                    />
                    
                    <ActivityItem 
                      icon="alert"
                      title="Price Alert"
                      subtitle="Potato prices have increased by 8%"
                      time="Yesterday at 10:15 AM"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </main>
        
        <MobileNav />
      </div>
    </div>
  );
}
