import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MarketPrice } from "@shared/schema";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, TrendingUp, TrendingDown, BarChart3 } from "lucide-react";

export default function MarketPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [marketFilter, setMarketFilter] = useState("");
  
  const { data: marketPrices, isLoading } = useQuery<MarketPrice[]>({
    queryKey: ["/api/market-prices"],
  });
  
  const filteredPrices = marketPrices
    ? marketPrices.filter(price => 
        price.productName.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (categoryFilter ? price.category === categoryFilter : true) &&
        (marketFilter ? price.market === marketFilter : true)
      )
    : [];
    
  // Get unique markets for the filter
  const markets = marketPrices
    ? [...new Set(marketPrices.map(price => price.market))]
    : [];
    
  // Mock data for price trends
  const priceTrends = {
    "Tomatoes": { change: 3.5, up: true },
    "Potatoes": { change: 8, up: true },
    "Apples": { change: 2.1, up: false },
    "Carrots": { change: 4.5, up: false },
    "Rice": { change: 1.2, up: true },
    "Corn": { change: 5.8, up: true }
  };

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-neutral-800 font-heading">Market Price Monitoring</h2>
              <p className="text-neutral-600">Track and compare market prices for your farm products</p>
            </div>

            {/* Price Trends Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
                    Rising Prices
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2">
                    {Object.entries(priceTrends)
                      .filter(([_, trend]) => trend.up)
                      .slice(0, 3)
                      .map(([product, trend]) => (
                        <li key={product} className="flex justify-between items-center text-sm py-1 border-b border-neutral-100">
                          <span>{product}</span>
                          <span className="text-green-600 font-medium flex items-center">
                            +{trend.change}%
                            <TrendingUp className="h-4 w-4 ml-1" />
                          </span>
                        </li>
                      ))}
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <TrendingDown className="h-5 w-5 mr-2 text-red-500" />
                    Falling Prices
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2">
                    {Object.entries(priceTrends)
                      .filter(([_, trend]) => !trend.up)
                      .slice(0, 3)
                      .map(([product, trend]) => (
                        <li key={product} className="flex justify-between items-center text-sm py-1 border-b border-neutral-100">
                          <span>{product}</span>
                          <span className="text-red-600 font-medium flex items-center">
                            -{trend.change}%
                            <TrendingDown className="h-4 w-4 ml-1" />
                          </span>
                        </li>
                      ))}
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-blue-500" />
                    Market Insights
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <ul className="space-y-2 text-sm">
                    <li className="py-1 border-b border-neutral-100">Fruit prices expected to rise in coming weeks due to seasonal changes</li>
                    <li className="py-1 border-b border-neutral-100">Grain prices stabilizing after recent fluctuations</li>
                    <li className="py-1">New export policies may affect vegetable market prices</li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Search Filters */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="search" className="mb-1 block">Search Products</Label>
                  <Input
                    id="search"
                    placeholder="Search by product name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="market-category" className="mb-1 block">Category</Label>
                  <Select 
                    value={categoryFilter} 
                    onValueChange={setCategoryFilter}
                  >
                    <SelectTrigger id="market-category">
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Categories</SelectItem>
                      <SelectItem value="vegetables">Vegetables</SelectItem>
                      <SelectItem value="fruits">Fruits</SelectItem>
                      <SelectItem value="grains">Grains</SelectItem>
                      <SelectItem value="dairy">Dairy</SelectItem>
                      <SelectItem value="livestock">Livestock</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="market" className="mb-1 block">Market</Label>
                  <Select 
                    value={marketFilter} 
                    onValueChange={setMarketFilter}
                  >
                    <SelectTrigger id="market">
                      <SelectValue placeholder="All Markets" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Markets</SelectItem>
                      {markets.map(market => (
                        <SelectItem key={market} value={market}>{market}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Market Prices Table */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Product</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Market</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Unit</TableHead>
                        <TableHead>Last Updated</TableHead>
                        <TableHead>Price Trend</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPrices.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="text-center py-8 text-neutral-500">
                            No market prices found matching your criteria.
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredPrices.map((price) => (
                          <TableRow key={price.id} className="hover:bg-neutral-50">
                            <TableCell className="font-medium">{price.productName}</TableCell>
                            <TableCell className="capitalize">{price.category}</TableCell>
                            <TableCell>{price.market}</TableCell>
                            <TableCell>${Number(price.price).toFixed(2)}</TableCell>
                            <TableCell>per {price.unit}</TableCell>
                            <TableCell>
                              {new Date(price.date).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              {priceTrends[price.productName as keyof typeof priceTrends] ? (
                                <span className={`flex items-center ${
                                  priceTrends[price.productName as keyof typeof priceTrends].up 
                                    ? "text-green-600" 
                                    : "text-red-600"
                                } font-medium`}>
                                  {priceTrends[price.productName as keyof typeof priceTrends].up ? "+" : "-"}
                                  {priceTrends[price.productName as keyof typeof priceTrends].change}%
                                  {priceTrends[price.productName as keyof typeof priceTrends].up 
                                    ? <TrendingUp className="h-4 w-4 ml-1" /> 
                                    : <TrendingDown className="h-4 w-4 ml-1" />
                                  }
                                </span>
                              ) : (
                                <span className="text-neutral-500">No data</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </div>
        </main>
        
        <MobileNav />
      </div>
    </div>
  );
}
