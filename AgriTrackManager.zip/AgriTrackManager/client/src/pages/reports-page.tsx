import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Product, Order, Transaction } from "@shared/schema";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsContent, TabsTrigger } from "@/components/ui/tabs";
import { 
  Loader2, 
  Download,
  BarChart3, 
  PieChart, 
  LineChart, 
  Table as TableIcon, 
  Calendar
} from "lucide-react";

// Sample recharts import for demo visuals
import { 
  BarChart,
  Bar, 
  PieChart as RePieChart, 
  Pie, 
  LineChart as ReLineChart, 
  Line, 
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell
} from "recharts";

export default function ReportsPage() {
  const [reportType, setReportType] = useState("sales");
  const [timeRange, setTimeRange] = useState("30days");
  
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });
  
  const { data: orders, isLoading: isLoadingOrders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });
  
  const { data: transactions, isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  const isLoading = isLoadingProducts || isLoadingOrders || isLoadingTransactions;

  // Generate chart data based on available data
  const generateSalesData = () => {
    if (!orders || orders.length === 0) return [];
    
    // Group by date and sum totals
    const salesByDate = orders.reduce((acc, order) => {
      const date = new Date(order.orderDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      acc[date] = (acc[date] || 0) + Number(order.totalAmount);
      return acc;
    }, {} as Record<string, number>);
    
    // Convert to array for charts
    return Object.entries(salesByDate).map(([date, amount]) => ({
      date,
      amount
    })).sort((a, b) => {
      // Sort by date
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateA.getTime() - dateB.getTime();
    });
  };
  
  const generateProductCategoryData = () => {
    if (!products || products.length === 0) return [];
    
    // Group by category and count
    const categoryCounts = products.reduce((acc, product) => {
      acc[product.category] = (acc[product.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    // Convert to array for charts
    return Object.entries(categoryCounts).map(([name, value]) => ({
      name,
      value
    }));
  };
  
  const generateFinancialData = () => {
    if (!transactions || transactions.length === 0) return [];
    
    // Group by date and separate income vs expenses
    const financialByDate = transactions.reduce((acc, transaction) => {
      const date = new Date(transaction.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      if (!acc[date]) {
        acc[date] = { date, income: 0, expenses: 0 };
      }
      
      if (transaction.type === 'income') {
        acc[date].income += Number(transaction.amount);
      } else {
        acc[date].expenses += Number(transaction.amount);
      }
      
      return acc;
    }, {} as Record<string, { date: string; income: number; expenses: number }>);
    
    // Convert to array and sort by date
    return Object.values(financialByDate).sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return dateA.getTime() - dateB.getTime();
    });
  };
  
  const salesData = generateSalesData();
  const productCategoryData = generateProductCategoryData();
  const financialData = generateFinancialData();
  
  // Colors for charts
  const COLORS = ['#2E7D32', '#FFA000', '#5D4037', '#4CAF50', '#FF9800', '#795548'];
  
  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-neutral-800 font-heading">Reports & Analytics</h2>
              <p className="text-neutral-600">Visualize and analyze your farm business performance</p>
            </div>

            {/* Report Controls */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="report-type" className="mb-1 block">Report Type</Label>
                  <Select 
                    value={reportType} 
                    onValueChange={setReportType}
                  >
                    <SelectTrigger id="report-type">
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sales">Sales Performance</SelectItem>
                      <SelectItem value="inventory">Inventory Overview</SelectItem>
                      <SelectItem value="financial">Financial Summary</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="time-range" className="mb-1 block">Time Range</Label>
                  <Select 
                    value={timeRange} 
                    onValueChange={setTimeRange}
                  >
                    <SelectTrigger id="time-range">
                      <SelectValue placeholder="Select time range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7days">Last 7 Days</SelectItem>
                      <SelectItem value="30days">Last 30 Days</SelectItem>
                      <SelectItem value="90days">Last 90 Days</SelectItem>
                      <SelectItem value="year">This Year</SelectItem>
                      <SelectItem value="all">All Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-end">
                  <Button variant="outline" className="w-full flex items-center gap-1">
                    <Download size={16} /> Export Report
                  </Button>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {reportType === "sales" && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <BarChart3 className="mr-2 h-5 w-5 text-primary" />
                          Sales Performance
                        </CardTitle>
                        <CardDescription>
                          Overview of your order sales over time
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Tabs defaultValue="chart" className="space-y-4">
                          <TabsList>
                            <TabsTrigger value="chart" className="flex items-center gap-1">
                              <BarChart3 className="h-4 w-4" /> Chart
                            </TabsTrigger>
                            <TabsTrigger value="summary" className="flex items-center gap-1">
                              <TableIcon className="h-4 w-4" /> Summary
                            </TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="chart" className="p-0">
                            <div className="h-80">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                  data={salesData}
                                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                                >
                                  <CartesianGrid strokeDasharray="3 3" />
                                  <XAxis dataKey="date" />
                                  <YAxis />
                                  <Tooltip formatter={(value) => [`$${value}`, 'Amount']} />
                                  <Legend />
                                  <Bar dataKey="amount" name="Sales Amount" fill="#2E7D32" />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </TabsContent>
                          
                          <TabsContent value="summary" className="p-0">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                              <Card>
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base font-medium">Total Orders</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <p className="text-2xl font-bold">
                                    {orders ? orders.length : 0}
                                  </p>
                                </CardContent>
                              </Card>
                              
                              <Card>
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base font-medium">Total Sales</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <p className="text-2xl font-bold">
                                    ${orders ? orders.reduce((sum, order) => sum + Number(order.totalAmount), 0).toFixed(2) : '0.00'}
                                  </p>
                                </CardContent>
                              </Card>
                              
                              <Card>
                                <CardHeader className="pb-2">
                                  <CardTitle className="text-base font-medium">Avg. Order Value</CardTitle>
                                </CardHeader>
                                <CardContent>
                                  <p className="text-2xl font-bold">
                                    ${orders && orders.length > 0 ? 
                                      (orders.reduce((sum, order) => sum + Number(order.totalAmount), 0) / orders.length).toFixed(2) 
                                      : '0.00'}
                                  </p>
                                </CardContent>
                              </Card>
                            </div>
                          </TabsContent>
                        </Tabs>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <LineChart className="mr-2 h-5 w-5 text-primary" />
                          Order Status Distribution
                        </CardTitle>
                        <CardDescription>
                          Breakdown of orders by status
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <RePieChart>
                              <Pie
                                dataKey="value"
                                isAnimationActive={true}
                                data={[
                                  { name: 'Pending', value: orders?.filter(o => o.status === 'pending').length || 0 },
                                  { name: 'Processing', value: orders?.filter(o => o.status === 'processing').length || 0 },
                                  { name: 'Completed', value: orders?.filter(o => o.status === 'completed').length || 0 },
                                  { name: 'Canceled', value: orders?.filter(o => o.status === 'canceled').length || 0 },
                                ]}
                                cx="50%"
                                cy="50%"
                                outerRadius={80}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              >
                                {[
                                  { name: 'Pending', value: orders?.filter(o => o.status === 'pending').length || 0 },
                                  { name: 'Processing', value: orders?.filter(o => o.status === 'processing').length || 0 },
                                  { name: 'Completed', value: orders?.filter(o => o.status === 'completed').length || 0 },
                                  { name: 'Canceled', value: orders?.filter(o => o.status === 'canceled').length || 0 },
                                ].map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip />
                              <Legend />
                            </RePieChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
                
                {reportType === "inventory" && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <PieChart className="mr-2 h-5 w-5 text-primary" />
                          Inventory by Category
                        </CardTitle>
                        <CardDescription>
                          Distribution of products across categories
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <RePieChart>
                              <Pie
                                dataKey="value"
                                isAnimationActive={true}
                                data={productCategoryData}
                                cx="50%"
                                cy="50%"
                                outerRadius={80}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              >
                                {productCategoryData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip />
                              <Legend />
                            </RePieChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <BarChart3 className="mr-2 h-5 w-5 text-primary" />
                          Inventory Status
                        </CardTitle>
                        <CardDescription>
                          Overview of stock status across products
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={[
                                { name: 'In Stock', value: products?.filter(p => p.status === 'in_stock').length || 0 },
                                { name: 'Low Stock', value: products?.filter(p => p.status === 'low_stock').length || 0 },
                                { name: 'Out of Stock', value: products?.filter(p => p.status === 'out_of_stock').length || 0 },
                              ]}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Bar dataKey="value" name="Products" fill="#2E7D32" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
                
                {reportType === "financial" && (
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <LineChart className="mr-2 h-5 w-5 text-primary" />
                          Income vs Expenses
                        </CardTitle>
                        <CardDescription>
                          Comparison of income and expenses over time
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <ReLineChart
                              data={financialData}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip formatter={(value) => [`$${value}`, '']} />
                              <Legend />
                              <Line type="monotone" dataKey="income" name="Income" stroke="#2E7D32" activeDot={{ r: 8 }} />
                              <Line type="monotone" dataKey="expenses" name="Expenses" stroke="#F44336" />
                            </ReLineChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <BarChart3 className="mr-2 h-5 w-5 text-primary" />
                          Financial Summary
                        </CardTitle>
                        <CardDescription>
                          Key financial metrics
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base font-medium">Total Income</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <p className="text-2xl font-bold text-green-600">
                                ${transactions ? 
                                  transactions
                                    .filter(tx => tx.type === 'income')
                                    .reduce((sum, tx) => sum + Number(tx.amount), 0)
                                    .toFixed(2) 
                                  : '0.00'}
                              </p>
                            </CardContent>
                          </Card>
                          
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base font-medium">Total Expenses</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <p className="text-2xl font-bold text-red-600">
                                ${transactions ? 
                                  transactions
                                    .filter(tx => tx.type === 'expense')
                                    .reduce((sum, tx) => sum + Number(tx.amount), 0)
                                    .toFixed(2) 
                                  : '0.00'}
                              </p>
                            </CardContent>
                          </Card>
                          
                          <Card>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-base font-medium">Net Profit</CardTitle>
                            </CardHeader>
                            <CardContent>
                              {transactions ? (() => {
                                const income = transactions
                                  .filter(tx => tx.type === 'income')
                                  .reduce((sum, tx) => sum + Number(tx.amount), 0);
                                
                                const expenses = transactions
                                  .filter(tx => tx.type === 'expense')
                                  .reduce((sum, tx) => sum + Number(tx.amount), 0);
                                
                                const profit = income - expenses;
                                return (
                                  <p className={`text-2xl font-bold ${profit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                                    ${profit.toFixed(2)}
                                  </p>
                                );
                              })() : (
                                <p className="text-2xl font-bold">$0.00</p>
                              )}
                            </CardContent>
                          </Card>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
        
        <MobileNav />
      </div>
    </div>
  );
}
