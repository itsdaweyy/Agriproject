import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Order, OrderStatus, PaymentStatus } from "@shared/schema";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Pencil, Loader2 } from "lucide-react";

export default function SalesPage() {
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case OrderStatus.PENDING:
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Pending</Badge>;
      case OrderStatus.PROCESSING:
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">Processing</Badge>;
      case OrderStatus.COMPLETED:
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Completed</Badge>;
      case OrderStatus.CANCELED:
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-200">Canceled</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case PaymentStatus.AWAITING:
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Awaiting</Badge>;
      case PaymentStatus.PAID:
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Paid</Badge>;
      case PaymentStatus.REFUNDED:
        return <Badge className="bg-neutral-100 text-neutral-800 hover:bg-neutral-200">Refunded</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const filteredOrders = orders
    ? orders.filter(order => {
        if (activeTab === "all") return true;
        return order.status.toLowerCase() === activeTab;
      })
    : [];

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-neutral-800 font-heading">Sales & Orders</h2>
              <p className="text-neutral-600">Manage your sales transactions and customer orders</p>
            </div>

            {/* Sales Tabs */}
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Orders</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="processing">Processing</TabsTrigger>
                <TabsTrigger value="completed">Completed</TabsTrigger>
                <TabsTrigger value="canceled">Canceled</TabsTrigger>
              </TabsList>
              
              <TabsContent value={activeTab}>
                <div className="bg-white rounded-lg shadow-md overflow-hidden">
                  {isLoading ? (
                    <div className="flex justify-center items-center h-64">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Order ID</TableHead>
                            <TableHead>Customer</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Total</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Payment</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredOrders.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={7} className="text-center py-8 text-neutral-500">
                                {activeTab === "all" 
                                  ? "No orders found." 
                                  : `No ${activeTab} orders found.`}
                              </TableCell>
                            </TableRow>
                          ) : (
                            filteredOrders.map((order) => (
                              <TableRow key={order.id} className="hover:bg-neutral-50">
                                <TableCell className="font-medium">{order.orderNumber}</TableCell>
                                <TableCell>
                                  Customer #{order.customerId}
                                </TableCell>
                                <TableCell>
                                  {new Date(order.orderDate).toLocaleDateString()}
                                </TableCell>
                                <TableCell>${Number(order.totalAmount).toFixed(2)}</TableCell>
                                <TableCell>{getStatusBadge(order.status)}</TableCell>
                                <TableCell>{getPaymentStatusBadge(order.paymentStatus)}</TableCell>
                                <TableCell>
                                  <div className="flex space-x-2">
                                    <Button 
                                      variant="ghost" 
                                      size="icon" 
                                      className="text-blue-500 hover:text-blue-700 hover:bg-blue-50"
                                    >
                                      <Eye size={16} />
                                    </Button>
                                    <Button 
                                      variant="ghost" 
                                      size="icon"
                                      className="text-primary-500 hover:text-primary-700 hover:bg-primary-50"
                                    >
                                      <Pencil size={16} />
                                    </Button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
        
        <MobileNav />
      </div>
    </div>
  );
}
