import { useState, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useLocation, useSearch } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Copy, Facebook, Twitter, Mail, Share2, Users, User, Sprout } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  role: z.string().optional(),
});

const registerSchema = z.object({
  fullName: z.string().min(3, { message: "Full name must be at least 3 characters" }),
  username: z.string().min(3, { message: "Username must be at least 3 characters" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string().min(6, { message: "Password must be at least 6 characters" }),
  role: z.string(),
  inviteCode: z.string().optional(),
  terms: z.literal(true, {
    errorMap: () => ({ message: "You must accept the terms and conditions" }),
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const [inviteUrl, setInviteUrl] = useState("");
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [location, navigate] = useLocation();
  const search = useSearch();
  const { toast } = useToast();
  const { user, loginMutation, registerMutation } = useAuth();

  // Check for invite code in URL parameters
  useEffect(() => {
    const params = new URLSearchParams(search);
    const inviteCode = params.get('inviteCode');
    if (inviteCode) {
      setActiveTab("register");
      registerForm.setValue("inviteCode", inviteCode);
      toast({
        title: "Invitation Detected",
        description: "You've been invited to join AgriTrack! Complete registration to get started.",
      });
    }
  }, [search]);

  // Generate invitation link
  useEffect(() => {
    // Create a unique invitation code using the current timestamp and a random string
    const inviteCode = `${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 7)}`;
    const baseUrl = window.location.origin;
    setInviteUrl(`${baseUrl}/auth?inviteCode=${inviteCode}`);
  }, []);

  // Redirect if already logged in
  if (user) {
    navigate("/");
    return null;
  }

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
      role: "farmer",
    },
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      fullName: "",
      username: "",
      password: "",
      confirmPassword: "",
      role: "farmer",
      inviteCode: "",
      terms: false,
    },
  });

  const onLoginSubmit = (values: LoginFormValues) => {
    loginMutation.mutate({
      username: values.username,
      password: values.password,
    });
  };

  const onRegisterSubmit = (values: RegisterFormValues) => {
    registerMutation.mutate({
      fullName: values.fullName,
      username: values.username,
      password: values.password,
      confirmPassword: values.confirmPassword,
      role: values.role,
    });
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteUrl).then(() => {
      toast({ 
        title: "Invitation Link Copied!",
        description: "Share this with friends to invite them to AgriTrack." 
      });
    });
  };

  const shareViaEmail = () => {
    const subject = encodeURIComponent("Join me on AgriTrack Farm Management System");
    const body = encodeURIComponent(`Hi there,\n\nI've been using AgriTrack to manage my farm operations and thought you might find it useful too. Use this link to join:\n\n${inviteUrl}\n\nBest,\n${user?.fullName || 'A fellow farmer'}`);
    window.open(`mailto:?subject=${subject}&body=${body}`);
  };

  const shareViaFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(inviteUrl)}`);
  };

  const shareViaTwitter = () => {
    const text = encodeURIComponent("Join me on AgriTrack, the all-in-one farm management system! Sign up here:");
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(inviteUrl)}`);
  };

  return (
    <div className="flex min-h-screen bg-neutral-50">
      {/* Left column - Auth forms */}
      <div className="flex flex-col items-center justify-center w-full lg:w-1/2 p-4 md:p-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
              <Sprout className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-primary font-heading">AgriTrack</h1>
            <p className="text-neutral-600">Farm Management System</p>
          </div>

          <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="login">Sign In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            {/* Login Tab */}
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Welcome Back</CardTitle>
                  <CardDescription>Sign in to access your account</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter your username" 
                                {...field} 
                                autoComplete="username"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="Enter your password" 
                                {...field} 
                                autoComplete="current-password"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="text-right">
                        <a href="#" className="text-sm font-medium text-primary hover:underline">
                          Forgot password?
                        </a>
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? "Signing in..." : "Sign in"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-center border-t pt-4">
                  <p className="text-sm text-center text-neutral-600">
                    Don't have an account? 
                    <Button
                      variant="link"
                      className="p-0 pl-1 text-primary"
                      onClick={() => setActiveTab("register")}
                    >
                      Register now
                    </Button>
                  </p>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Register Tab */}
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Create an Account</CardTitle>
                  <CardDescription>Join AgriTrack and start managing your farm efficiently</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Choose a username" 
                                {...field} 
                                autoComplete="username"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password" 
                                  placeholder="Create a password" 
                                  {...field} 
                                  autoComplete="new-password"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password" 
                                  placeholder="Confirm your password" 
                                  {...field} 
                                  autoComplete="new-password"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={registerForm.control}
                        name="role"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Account Type</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="farmer">Farmer</SelectItem>
                                <SelectItem value="buyer">Buyer</SelectItem>
                                <SelectItem value="distributor">Distributor</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="inviteCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Invitation Code <span className="text-xs text-neutral-500">(Optional)</span></FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="Enter invitation code if you have one" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="terms"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 py-2">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel className="text-sm font-normal">
                                I agree to the <a href="#" className="text-primary hover:underline">Terms and Conditions</a>
                              </FormLabel>
                              <FormMessage />
                            </div>
                          </FormItem>
                        )}
                      />

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? "Creating Account..." : "Register"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-center border-t pt-4">
                  <p className="text-sm text-center text-neutral-600">
                    Already have an account?
                    <Button
                      variant="link"
                      className="p-0 pl-1 text-primary"
                      onClick={() => setActiveTab("login")}
                    >
                      Sign in
                    </Button>
                  </p>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Right column - Hero/Intro */}
      <div className="hidden lg:flex flex-col w-1/2 bg-primary-50 p-8 items-center justify-center relative overflow-hidden">
        <div className="max-w-lg relative z-10">
          <h2 className="text-3xl font-bold text-primary mb-4">Manage Your Farm Operations with Ease</h2>
          <p className="text-neutral-700 mb-8">
            AgriTrack helps farmers, buyers, and distributors track inventory, manage sales, 
            monitor market prices, and handle finances all in one place.
          </p>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 className="text-lg font-semibold text-primary mb-4 flex items-center">
              <Users className="h-5 w-5 mr-2" /> Invite Friends & Colleagues
            </h3>
            <p className="text-sm text-neutral-600 mb-4">
              Share AgriTrack with your network and collaborate more effectively.
            </p>
            
            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={copyInviteLink}
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy Invitation Link
              </Button>
              
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full"
                  onClick={shareViaEmail}
                >
                  <Mail className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full"
                  onClick={shareViaFacebook}
                >
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="w-full"
                  onClick={shareViaTwitter}
                >
                  <Twitter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur rounded-lg p-6 shadow-md">
            <h3 className="text-lg font-semibold text-primary mb-2">What Our Users Say</h3>
            <blockquote className="border-l-2 border-primary-200 pl-4 italic text-sm text-neutral-700">
              "AgriTrack has transformed how we manage our farming operations. The collaborative features make it easy to work with buyers and distributors."
            </blockquote>
            <div className="flex items-center mt-4">
              <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center">
                <User className="h-4 w-4 text-primary" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium">John Farmer</p>
                <p className="text-xs text-neutral-500">Green Valley Farms</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Background decorative elements */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-primary-200 rounded-full opacity-20 -translate-y-1/3 translate-x-1/3"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-primary-300 rounded-full opacity-20 translate-y-1/3 -translate-x-1/3"></div>
      </div>
    </div>
  );
}
