import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Transaction, TransactionType, insertTransactionSchema } from "@shared/schema";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { 
  Loader2, 
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  DollarSign,
  TrendingUp,
  ArrowUpCircle,
  ArrowDownCircle,
  CalendarRange
} from "lucide-react";

const transactionFormSchema = z.object({
  type: z.string(),
  amount: z.string().min(1, "Amount is required"),
  description: z.string().min(1, "Description is required"),
  category: z.string().optional(),
  date: z.string().min(1, "Date is required"),
});

type TransactionFormValues = z.infer<typeof transactionFormSchema>;

export default function FinancePage() {
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("all");
  
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  const form = useForm<TransactionFormValues>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      type: TransactionType.INCOME,
      amount: "",
      description: "",
      category: "",
      date: new Date().toISOString().split('T')[0], // Today's date in YYYY-MM-DD format
    },
  });
  
  const createTransactionMutation = useMutation({
    mutationFn: async (data: TransactionFormValues) => {
      const transaction = {
        ...data,
        amount: data.amount,
      };
      const res = await apiRequest("POST", "/api/transactions", transaction);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({
        title: "Transaction recorded",
        description: "The transaction has been successfully recorded",
      });
      setIsDialogOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to record transaction",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: TransactionFormValues) => {
    createTransactionMutation.mutate(values);
  };
  
  const filteredTransactions = transactions
    ? transactions
        .filter(transaction => {
          if (activeTab === "all") return true;
          return transaction.type.toLowerCase() === activeTab;
        })
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];
  
  // Calculate financial overview
  const calculateFinancialOverview = () => {
    if (!transactions) return { totalIncome: 0, totalExpenses: 0, netProfit: 0 };
    
    const totalIncome = transactions
      .filter(tx => tx.type === TransactionType.INCOME)
      .reduce((sum, tx) => sum + Number(tx.amount), 0);
      
    const totalExpenses = transactions
      .filter(tx => tx.type === TransactionType.EXPENSE)
      .reduce((sum, tx) => sum + Number(tx.amount), 0);
      
    const netProfit = totalIncome - totalExpenses;
    
    return { totalIncome, totalExpenses, netProfit };
  };
  
  const financials = calculateFinancialOverview();

  return (
    <div className="flex h-screen bg-neutral-100">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto bg-neutral-50 p-4">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-semibold text-neutral-800 font-heading">Financial Management</h2>
                <p className="text-neutral-600">Track income, expenses, and financial performance</p>
              </div>
              
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="flex items-center gap-1">
                    <Plus size={16} /> Add Transaction
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Record New Transaction</DialogTitle>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Transaction Type</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value={TransactionType.INCOME}>Income</SelectItem>
                                <SelectItem value={TransactionType.EXPENSE}>Expense</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount ($)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" placeholder="0.00" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter transaction description" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category (Optional)</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="sales">Sales</SelectItem>
                                <SelectItem value="supplies">Supplies</SelectItem>
                                <SelectItem value="equipment">Equipment</SelectItem>
                                <SelectItem value="labor">Labor</SelectItem>
                                <SelectItem value="transportation">Transportation</SelectItem>
                                <SelectItem value="utilities">Utilities</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="date"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <DialogFooter className="pt-4">
                        <DialogClose asChild>
                          <Button type="button" variant="outline">Cancel</Button>
                        </DialogClose>
                        <Button 
                          type="submit" 
                          disabled={createTransactionMutation.isPending}
                        >
                          {createTransactionMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            "Record Transaction"
                          )}
                        </Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Financial Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <ArrowUpCircle className="h-5 w-5 mr-2 text-green-600" />
                    Total Income
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-green-600">${financials.totalIncome.toFixed(2)}</p>
                  <p className="text-sm text-neutral-600 mt-1">Year to date</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <ArrowDownCircle className="h-5 w-5 mr-2 text-red-600" />
                    Total Expenses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">${financials.totalExpenses.toFixed(2)}</p>
                  <p className="text-sm text-neutral-600 mt-1">Year to date</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-neutral-700 flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
                    Net Profit
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-3xl font-bold ${financials.netProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                    ${financials.netProfit.toFixed(2)}
                  </p>
                  <p className="text-sm text-neutral-600 mt-1">Year to date</p>
                </CardContent>
              </Card>
            </div>

            {/* Transactions List */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
              <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
                <div className="px-4 pt-4">
                  <h3 className="text-lg font-medium text-neutral-800 mb-4">Transaction History</h3>
                  <TabsList>
                    <TabsTrigger value="all">All Transactions</TabsTrigger>
                    <TabsTrigger value="income">Income</TabsTrigger>
                    <TabsTrigger value="expense">Expenses</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value={activeTab} className="p-0">
                  {isLoading ? (
                    <div className="flex justify-center items-center h-64">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Date</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredTransactions.length === 0 ? (
                            <TableRow>
                              <TableCell colSpan={5} className="text-center py-8 text-neutral-500">
                                No transactions found. Add some transactions to track your finances.
                              </TableCell>
                            </TableRow>
                          ) : (
                            filteredTransactions.map((transaction) => (
                              <TableRow key={transaction.id} className="hover:bg-neutral-50">
                                <TableCell className="flex items-center">
                                  <CalendarRange className="h-4 w-4 mr-2 text-neutral-400" />
                                  {new Date(transaction.date).toLocaleDateString()}
                                </TableCell>
                                <TableCell>
                                  {transaction.type === TransactionType.INCOME ? (
                                    <Badge className="bg-green-100 text-green-800 hover:bg-green-200 flex items-center w-fit">
                                      <ArrowUpRight className="h-3 w-3 mr-1" />
                                      Income
                                    </Badge>
                                  ) : (
                                    <Badge className="bg-red-100 text-red-800 hover:bg-red-200 flex items-center w-fit">
                                      <ArrowDownLeft className="h-3 w-3 mr-1" />
                                      Expense
                                    </Badge>
                                  )}
                                </TableCell>
                                <TableCell>{transaction.description}</TableCell>
                                <TableCell>
                                  {transaction.category ? (
                                    <Badge variant="outline" className="capitalize">
                                      {transaction.category}
                                    </Badge>
                                  ) : (
                                    <span className="text-neutral-400">—</span>
                                  )}
                                </TableCell>
                                <TableCell className={`font-medium ${
                                  transaction.type === TransactionType.INCOME 
                                    ? 'text-green-600' 
                                    : 'text-red-600'
                                }`}>
                                  {transaction.type === TransactionType.INCOME ? '+' : '-'}${Number(transaction.amount).toFixed(2)}
                                </TableCell>
                              </TableRow>
                            ))
                          )}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </main>
        
        <MobileNav />
      </div>
    </div>
  );
}
