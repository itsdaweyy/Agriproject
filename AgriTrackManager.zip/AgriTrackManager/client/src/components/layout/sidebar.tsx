import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { UserRole } from "@shared/schema";
import { 
  Home, 
  Package, 
  ShoppingCart, 
  BarChart2, 
  DollarSign, 
  FileText, 
  LogOut,
  Loader2,
  UserCog
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navItems = [
    { path: "/", icon: <Home className="h-5 w-5" />, label: "Dashboard" },
    { path: "/inventory", icon: <Package className="h-5 w-5" />, label: "Inventory" },
    { path: "/sales", icon: <ShoppingCart className="h-5 w-5" />, label: "Sales" },
    { path: "/market", icon: <BarChart2 className="h-5 w-5" />, label: "Market" },
    { path: "/finance", icon: <DollarSign className="h-5 w-5" />, label: "Finance" },
    { path: "/reports", icon: <FileText className="h-5 w-5" />, label: "Reports" },
  ];
  
  // Admin item that will only show for users with admin role
  const adminItem = { 
    path: "/admin", 
    icon: <UserCog className="h-5 w-5" />, 
    label: "Admin Dashboard"
  };

  return (
    <div className="hidden md:flex flex-col bg-white shadow-md h-screen w-64">
      <div className="p-6">
        <h1 className="text-xl font-bold text-primary font-heading">AgriTrack</h1>
        <p className="text-sm text-neutral-500">Farm Management System</p>
      </div>
      
      <div className="flex-1 px-4 py-2">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                location === item.path
                  ? "bg-primary text-white"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}>
                {item.icon}
                {item.label}
              </a>
            </Link>
          ))}
          
          {/* Admin link - only visible to admin users */}
          {user?.role === UserRole.ADMIN && (
            <Link href={adminItem.path}>
              <a className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                location === adminItem.path
                  ? "bg-primary text-white"
                  : "text-neutral-700 hover:bg-neutral-100",
                "mt-4 border-t pt-4"
              )}>
                {adminItem.icon}
                {adminItem.label}
              </a>
            </Link>
          )}
        </div>
      </div>
      
      <div className="p-4 border-t border-neutral-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center text-primary font-semibold">
            {user?.fullName?.charAt(0) || "U"}
          </div>
          <div>
            <p className="font-medium text-sm text-neutral-800">{user?.fullName}</p>
            <p className="text-xs text-neutral-500 capitalize">{user?.role}</p>
          </div>
        </div>
        
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2 w-full rounded-md text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <LogOut className="h-5 w-5" />
          )}
          Sign Out
        </button>
      </div>
    </div>
  );
}
