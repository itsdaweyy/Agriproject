import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Bell, User, ChevronDown, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import NotificationsPanel from "./notifications-panel";

export default function Header() {
  const { user, logoutMutation } = useAuth();
  const [notificationsPanelOpen, setNotificationsPanelOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const toggleNotificationsPanel = () => {
    setNotificationsPanelOpen(!notificationsPanelOpen);
  };
  
  return (
    <header className="bg-white shadow-md py-4 px-6 flex items-center justify-between md:px-8">
      <div className="flex md:hidden">
        <Menu className="h-6 w-6 text-neutral-700" />
      </div>
      
      <div className="md:hidden flex items-center">
        <h1 className="text-lg font-semibold text-primary">AgriTrack</h1>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="relative">
          <Button 
            onClick={toggleNotificationsPanel} 
            variant="ghost" 
            size="icon" 
            className="text-neutral-500 hover:text-neutral-700 relative"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500"></span>
          </Button>
          
          {notificationsPanelOpen && <NotificationsPanel onClose={() => setNotificationsPanelOpen(false)} />}
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2 text-sm">
              <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary font-semibold">
                {user?.fullName?.charAt(0) || "U"}
              </div>
              <div className="hidden md:block text-left">
                <p className="font-medium">{user?.fullName}</p>
                <p className="text-xs text-neutral-500 capitalize">{user?.role}</p>
              </div>
              <ChevronDown className="h-4 w-4 text-neutral-500" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <div className="flex items-center gap-2 p-2 md:hidden">
              <p className="font-medium">{user?.fullName}</p>
              <span className="text-xs bg-primary-100 text-primary px-1.5 py-0.5 rounded-full capitalize">{user?.role}</span>
            </div>
            <DropdownMenuSeparator className="md:hidden" />
            <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
              <User className="h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="flex items-center gap-2 text-red-600 cursor-pointer" 
              onClick={handleLogout}
            >
              <span>Sign out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
