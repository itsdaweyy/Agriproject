import { CircleDollarSign, ShoppingCart, Package, AlertTriangle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

type NotificationsPanelProps = {
  onClose: () => void;
};

// Sample notification data - would typically come from API
const notifications = [
  {
    id: 1,
    type: "order",
    title: "New order received",
    description: "Order #OR-789 from Sophia's Organic Market",
    time: "30 minutes ago",
  },
  {
    id: 2,
    type: "inventory",
    title: "Low Stock Alert",
    description: "Carrots inventory is below minimum threshold",
    time: "2 hours ago",
  },
  {
    id: 3,
    type: "price",
    title: "Price Change Alert",
    description: "Potato prices have increased by 8%",
    time: "Yesterday at 10:15 AM",
  },
  {
    id: 4,
    type: "payment",
    title: "Payment Received",
    description: "$345.00 for Order #OR-654",
    time: "Yesterday at 4:30 PM",
  },
  {
    id: 5,
    type: "order",
    title: "Order #OR-652 Shipped",
    description: "Delivered to Green Foods Inc.",
    time: "2 days ago",
  },
];

export default function NotificationsPanel({ onClose }: NotificationsPanelProps) {
  // Function to render appropriate icon based on notification type
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "order":
        return <ShoppingCart className="h-5 w-5 text-blue-600" />;
      case "inventory":
        return <Package className="h-5 w-5 text-primary-600" />;
      case "price":
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      case "payment":
        return <CircleDollarSign className="h-5 w-5 text-green-600" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-neutral-600" />;
    }
  };

  const getIconBackground = (type: string) => {
    switch (type) {
      case "order":
        return "bg-blue-100";
      case "inventory":
        return "bg-primary-100";
      case "price":
        return "bg-red-100";
      case "payment":
        return "bg-green-100";
      default:
        return "bg-neutral-100";
    }
  };

  return (
    <div className="fixed right-4 top-16 w-80 bg-white rounded-md shadow-lg overflow-hidden z-50">
      <div className="p-3 bg-primary-50 border-b border-primary-100 flex justify-between items-center">
        <h3 className="text-sm font-medium text-primary-800">Notifications</h3>
        <Button size="icon" variant="ghost" className="h-6 w-6" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <div className="max-h-96 overflow-y-auto">
        {notifications.map((notification) => (
          <div 
            key={notification.id} 
            className="p-3 hover:bg-neutral-50 border-b border-neutral-100 cursor-pointer"
          >
            <div className="flex items-start">
              <div className={`rounded-full p-2 mr-3 ${getIconBackground(notification.type)}`}>
                {getNotificationIcon(notification.type)}
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-800">{notification.title}</p>
                <p className="text-xs text-neutral-500">{notification.description}</p>
                <p className="text-xs text-neutral-400">{notification.time}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="p-2 bg-neutral-50 text-center border-t border-neutral-100">
        <a href="#" className="text-xs text-primary-600 hover:text-primary-800">View all notifications</a>
      </div>
    </div>
  );
}
