import { useState } from "react";
import { useLocation, Link } from "wouter";
import { UserRole } from "@shared/schema";
import { 
  Home, 
  Package, 
  ShoppingCart, 
  Menu, 
  X, 
  BarChart2, 
  DollarSign, 
  FileText, 
  Settings, 
  User, 
  LogOut,
  UserCog
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

export default function MobileNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
    setMoreMenuOpen(false);
  };
  
  const baseNavItems = [
    { path: "/", icon: <Home className="h-6 w-6" />, label: "Dashboard" },
    { path: "/inventory", icon: <Package className="h-6 w-6" />, label: "Inventory" },
    { path: "/sales", icon: <ShoppingCart className="h-6 w-6" />, label: "Sales" },
  ];
  
  const moreNavItems = [
    { path: "/market", icon: <BarChart2 className="h-6 w-6" />, label: "Market" },
    { path: "/finance", icon: <DollarSign className="h-6 w-6" />, label: "Finance" },
    { path: "/reports", icon: <FileText className="h-6 w-6" />, label: "Reports" },
  ];
  
  return (
    <>
      <div className="fixed bottom-0 left-0 z-50 w-full h-16 bg-white border-t border-neutral-200 md:hidden">
        <div className="grid h-full grid-cols-4">
          {baseNavItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a className={cn(
                "flex flex-col items-center justify-center px-4",
                location === item.path
                  ? "text-primary"
                  : "text-neutral-500"
              )}>
                {item.icon}
                <span className="text-xs mt-1">{item.label}</span>
              </a>
            </Link>
          ))}
          
          <button 
            onClick={() => setMoreMenuOpen(true)}
            className="flex flex-col items-center justify-center px-4 text-neutral-500"
          >
            <Menu className="h-6 w-6" />
            <span className="text-xs mt-1">More</span>
          </button>
        </div>
      </div>
      
      {/* More Menu (Mobile) */}
      {moreMenuOpen && (
        <div className="fixed inset-0 bg-neutral-800 bg-opacity-75 z-50 md:hidden">
          <div className="bg-white rounded-t-lg absolute bottom-0 w-full max-h-[80vh] overflow-y-auto">
            <div className="p-4 border-b">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium text-neutral-800">More Options</h3>
                <button 
                  onClick={() => setMoreMenuOpen(false)}
                  className="text-neutral-500 hover:text-neutral-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-3 gap-4">
                {moreNavItems.map((item) => (
                  <Link key={item.path} href={item.path} onClick={() => setMoreMenuOpen(false)}>
                    <a className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-neutral-50">
                      <div className="bg-primary-100 p-3 rounded-full mb-2">
                        {item.icon}
                      </div>
                      <span className="text-sm text-neutral-700">{item.label}</span>
                    </a>
                  </Link>
                ))}
                
                {/* Admin option - only shown for admin users */}
                {user?.role === UserRole.ADMIN && (
                  <Link href="/admin" onClick={() => setMoreMenuOpen(false)}>
                    <a className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-neutral-50">
                      <div className="bg-purple-100 p-3 rounded-full mb-2">
                        <UserCog className="h-6 w-6 text-purple-600" />
                      </div>
                      <span className="text-sm text-neutral-700">Admin</span>
                    </a>
                  </Link>
                )}
                
                <a href="#" className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-neutral-50">
                  <div className="bg-primary-100 p-3 rounded-full mb-2">
                    <Settings className="h-6 w-6 text-primary" />
                  </div>
                  <span className="text-sm text-neutral-700">Settings</span>
                </a>
                
                <a href="#" className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-neutral-50">
                  <div className="bg-primary-100 p-3 rounded-full mb-2">
                    <User className="h-6 w-6 text-primary" />
                  </div>
                  <span className="text-sm text-neutral-700">Profile</span>
                </a>
                
                <button 
                  onClick={handleLogout}
                  className="flex flex-col items-center justify-center p-4 rounded-lg hover:bg-neutral-50"
                >
                  <div className="bg-red-100 p-3 rounded-full mb-2">
                    <LogOut className="h-6 w-6 text-red-500" />
                  </div>
                  <span className="text-sm text-neutral-700">Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
