import { useEffect, useState } from "react";
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  Legend, 
  Tooltip, 
  ResponsiveContainer,
  XAxis,
  YAxis 
} from "recharts";

type ChartContainerProps = {
  title: string;
  type: "bar" | "pie";
};

const salesData = [
  { name: "Jan", amount: 2100 },
  { name: "Feb", amount: 2800 },
  { name: "Mar", amount: 1750 },
  { name: "Apr", amount: 3500 },
  { name: "May", amount: 3000 },
  { name: "Jun", amount: 4250 },
  { name: "Jul", amount: 3750 },
  { name: "Aug", amount: 3250 },
  { name: "Sep", amount: 4000 },
  { name: "Oct", amount: 4500 },
  { name: "Nov", amount: 4750 },
  { name: "Dec", amount: 5000 },
];

const productDistribution = [
  { name: "Vegetables", value: 35 },
  { name: "Fruits", value: 25 },
  { name: "Grains", value: 20 },
  { name: "Others", value: 20 },
];

const COLORS = ["#2E7D32", "#FFA000", "#5D4037", "#4CAF50"];

export default function ChartContainer({ title, type }: ChartContainerProps) {
  const [activeMonth, setActiveMonth] = useState<string | null>(null);
  
  const renderBarChart = () => (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={salesData} margin={{ top: 10, right: 10, left: 10, bottom: 5 }}>
        <XAxis dataKey="name" fontSize={10} />
        <YAxis hide />
        <Tooltip 
          formatter={(value) => [`$${value}`, 'Revenue']}
          labelFormatter={(label) => `Month: ${label}`}
        />
        <Bar 
          dataKey="amount" 
          fill="#2E7D32" 
          radius={[4, 4, 0, 0]}
          onMouseOver={(data) => {
            setActiveMonth(data.name);
          }}
          onMouseLeave={() => {
            setActiveMonth(null);
          }}
        >
          {salesData.map((entry, index) => (
            <Cell 
              key={`cell-${index}`} 
              fill={entry.name === activeMonth || entry.name === "Jun" ? "#2E7D32" : "#81C784"} 
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
  
  const renderPieChart = () => (
    <ResponsiveContainer width="100%" height={240}>
      <PieChart margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
        <Pie
          data={productDistribution}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={80}
          paddingAngle={2}
          dataKey="value"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
        >
          {productDistribution.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip 
          formatter={(value) => [`${value}%`, 'Percentage']}
        />
        <Legend 
          align="center" 
          verticalAlign="bottom" 
          layout="horizontal" 
          iconSize={10}
          iconType="circle"
        />
      </PieChart>
    </ResponsiveContainer>
  );

  return (
    <div className="bg-white rounded-lg shadow-md p-4 h-auto">
      <h3 className="text-md font-medium text-neutral-700 mb-4">{title}</h3>
      {type === "bar" ? renderBarChart() : renderPieChart()}
    </div>
  );
}
