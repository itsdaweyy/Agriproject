import { ReactNode } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

type StatsCardProps = {
  title: string;
  value: number | string;
  icon: ReactNode;
  trend?: {
    value: number;
    isUp: boolean;
    label: string;
  };
  label?: string;
  color: "primary" | "secondary" | "earth" | "green";
};

export default function StatsCard({ title, value, icon, trend, label, color }: StatsCardProps) {
  const colorClasses = {
    primary: {
      border: "border-primary",
      text: "text-primary",
    },
    secondary: {
      border: "border-secondary-500",
      text: "text-secondary-500",
    },
    earth: {
      border: "border-earth-500",
      text: "text-earth-500",
    },
    green: {
      border: "border-green-500",
      text: "text-green-500",
    },
  };

  return (
    <div className={cn(
      "bg-white border-l-4 rounded-lg shadow-md hover:shadow-lg p-4 transition-all duration-300",
      colorClasses[color].border
    )}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-neutral-500 mb-1">{title}</p>
          <p className={cn(
            "text-2xl sm:text-3xl font-semibold",
            colorClasses[color].text
          )}>
            {value}
          </p>
        </div>
        <div className="p-2 bg-neutral-100 rounded-lg">
          {icon}
        </div>
      </div>
      
      <div className="flex items-center mt-1">
        {trend ? (
          <>
            <span className={cn(
              "text-xs font-medium flex items-center",
              trend.isUp ? "text-green-500" : "text-red-500"
            )}>
              {trend.isUp ? (
                <TrendingUp className="h-3 w-3 mr-1" />
              ) : (
                <TrendingDown className="h-3 w-3 mr-1" />
              )}
              {trend.value}%
            </span>
            <span className="text-neutral-400 text-xs ml-1">{trend.label}</span>
          </>
        ) : (
          <span className="text-neutral-400 text-xs">{label}</span>
        )}
      </div>
    </div>
  );
}
