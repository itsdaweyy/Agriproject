import { 
  CircleDollarSign, 
  Package, 
  ClipboardList, 
  AlertTriangle 
} from "lucide-react";

type ActivityItemProps = {
  icon: "money" | "inventory" | "order" | "alert";
  title: string;
  subtitle: string;
  time: string;
};

export default function ActivityItem({ icon, title, subtitle, time }: ActivityItemProps) {
  const getIcon = () => {
    switch (icon) {
      case "money":
        return (
          <div className="bg-green-100 rounded-full p-2 mr-3">
            <CircleDollarSign className="h-5 w-5 text-green-600" />
          </div>
        );
      case "inventory":
        return (
          <div className="bg-primary-100 rounded-full p-2 mr-3">
            <Package className="h-5 w-5 text-primary-600" />
          </div>
        );
      case "order":
        return (
          <div className="bg-secondary-100 rounded-full p-2 mr-3">
            <ClipboardList className="h-5 w-5 text-secondary-600" />
          </div>
        );
      case "alert":
        return (
          <div className="bg-red-100 rounded-full p-2 mr-3">
            <AlertTriangle className="h-5 w-5 text-red-600" />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex items-start p-2 hover:bg-neutral-50 rounded-lg transition-colors cursor-pointer">
      {getIcon()}
      <div>
        <p className="text-sm font-medium text-neutral-800">{title}</p>
        <p className="text-xs text-neutral-500">{subtitle}</p>
        <p className="text-xs text-neutral-400">{time}</p>
      </div>
    </div>
  );
}
